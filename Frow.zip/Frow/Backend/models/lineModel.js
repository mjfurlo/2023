const mongoose = require('mongoose')

const productLineSchema = mongoose.Schema({
    name: {
        type: String,
        required: [true, "Please add a name"]
    },
    designerID: {
        type: String,
        required: [true, 'Please add a designer ID']
    },
    description: {
        type: String,
        required: [true, 'Please add a description']
    },
    showID: {
        type: String,
        required: false
    }
})

module.exports = mongoose.model('ProductLines', productLineSchema)