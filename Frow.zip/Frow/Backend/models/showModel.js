const mongoose = require('mongoose')

const showSchema = mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please add name']
    },
    date: {
        type: String,
        required: [true, 'Please add Date']
    },
    description: {
        type: String
    },
    videoLink:{
        type: String,
        required: [true, "Please add youtube link"]
    },
    time:{
        type: String,
        required: [true, "Please add time"]
    },
    designerIDS: [{
        type: String
    }]

})

module.exports = mongoose.model('Shows', showSchema)