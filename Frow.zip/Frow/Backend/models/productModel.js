const mongoose = require('mongoose')

const productSchema = mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please add a name']
    }, 
    price: {
        type: String,
        required: [true, 'Please add a price']
    },
    date: {
        type: String,
        required: [true, 'Please add a date']
    },
    description: {
        type: String
    },
    img_url: {
        type: String,
        required: [true, 'Please add an Image URL']
    },
    designerID: {
        type: String,
        required: [true, 'Please add a designer ID']
    },
    showID: {
        type: String,
        required: false
    },
    productLineID: {
        type: String,
        required: [true, ' Please add proudct line ID']
    }
},
{
    timestamps: true
})

module.exports = mongoose.model('Products', productSchema)