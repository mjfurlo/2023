const asyncHandler = require('express-async-handler')
const mongoose = require('mongoose')
const Product = require('../models/productModel')

// @desc Create Product Listing
// @route POST /api/products/createProduct
// @access Private
// req.query showID
// req.query designerID
const createProduct = asyncHandler(async(req, res) => {
    if (!req.body) {
        res.status(400)
        throw new Error('Please add a text field')
    }

    const product = await Product.create({
        name: req.body.name,
        price: req.body.price,
        date: req.body.date,
        description: req.body.description,
        img_url: req.body.img_url,
        designerID: req.query.designerID,
        showID: req.body.showID,
        productLineID: req.body.productLineID
    })

    res.status(200).json(product)
})


// @desc Get all products
// @route GET /api/all
// @access Private
const getAllProducts = asyncHandler(async(req, res) => {
    const products = await Product.find();
    res.status(200).json(products)
})

// @desc Get products by designer
// @route GET /api/products/designer/{id}
// @access Private
const getProductByDesigner = asyncHandler(async(req, res) => {
    let product = await Product.find({
        designerID: req.body.designerID
    });
    res.status(200).json(product)
})

// @desc Get products by designer
// @route GET /api/products/productLine/{productLine}
// @access Private
const getProductByProductLine = asyncHandler(async(req, res) => {
    let product = await Product.find({
        productLineID: req.body.productLineID
    })
    res.status(200).json(product)
})

// @desc Get products by show
// @route GET /api/products/show/{id}
// @access Private
const getProductByShow = asyncHandler(async(req, res) => {
    let product = await Product.find({
        showID: req.body.showID
    });
    res.status(200).json(product)
})

// @desc Get products by ID
// @route GET /api/products/{id}
// @access Private
const getProductByID = asyncHandler(async(req, res) => {
    let product = await Product.findOne({
        _id: req.query.productID
    })
    res.status(200).json(product)
})

// @desc Update Products by ID
// @route PUT /api/products/{PRODUCT_ID}
// @access Private
const updateProduct = asyncHandler(async(req, res) => {
    const product = await Product.findById(req.params.id)

    if (!product) {
        res.status(400)
        throw new Error('Product not found')
    }
    const updatedProduct = await Product.findByIdAndUpdate(req.params.id, req.body, {new: true})
    res.status(200).json(updatedProduct)
})

// @desc Delete Products by ID
// @route PUT /api/products/{PRODUCT_ID}
// @access Private
const deleteProduct = asyncHandler(async(req, res) => {
    const product = await Product.findById(req.params.id)

    if (!product) {
        res.status(400)
        throw new Error("Product not found")
    }

    await product.remove()
    res.status(200).json({ id: req.params.id })
})

module.exports = {
    createProduct,
    getAllProducts,
    getProductByDesigner,
    getProductByShow,
    getProductByID,
    updateProduct,
    deleteProduct,
    getProductByProductLine
}