const asyncHandler = require('express-async-handler')
const { ServerDescription } = require('mongodb')
const mongoose = require('mongoose')
const ProductLine = require('../models/lineModel')

// @desc Get all product lines
// @route GET /api/productLines/all
// @access Private
const getAllProductLines = asyncHandler(async(req, res) => {
    const productLine = await ProductLine.find()
    res.status(200).json(productLine)
})

//@desc Get product line by showID
//@route GET /API/productLines/show/{id}
//@access Private
const getProductLineByShowID = asyncHandler(async(req, res) => {
    let productLine = await ProductLine.find({
        showID: req.body.showID
    })
    res.status(200).json(productLine)
})
    
// @desc Get product line by designerID
// @route GET /api/products/designer/{id}
// @access Private
const getProductLineByDesigner = asyncHandler(async(req, res) => {
    let productLine = await ProductLine.find({
        designerID: req.body.designerID
    })
    res.status(200).json(productLine)
})

//@desc Get product line by showID
//@route GET /api/productLines/show/{Showid}/designer/{designerID}
//@access Private
const getProductLineByShowIDAndDesignerID = asyncHandler(async(req, res) => {
    let productLine = await ProductLine.find({
        showID: req.body.showID,
        designerID: req.body.designerID
    })
    res.status(200).json(productLine)
})

//@desc Create product line
//@route POST /api/productLines/createProductLine
//@access Private
const createProductLine = asyncHandler(async(req,res) => {
    if (!req.body){
        res.status(400)
        throw new Error('Please add a text field')
    }
    const productLine = await ProductLine.create({
        name: req.body.name,
        designerID: req.body.designerID,
        description: req.body.description,
        showID: req.body.showID
    })

    res.status(200).json(productLine)
})

//@desc update product line
//@route PUT /api/productLines/{ProductLineID}
//@access private
const updateProductLine = asyncHandler(async(req, res) => {
    const productLine = await ProductLine.findById(req.params.id)

    if (!productLine) {
        res.status(400)
        throw new Error('Product Line Not Found')
    }
    const updatedProductLine = await ProductLine.findByIdAndUpdate(req.params.id, req.body, {new: true})
    res.status(200).json(updatedProductLine)
})

//@desc delete product line
//@route DEL /api/productLines/{ProductLineID}
//@access private
const deleteProductLine = asyncHandler(async(req, res) => {
    const productLine = await ProductLine.findById(req.params.id)

    if (!productLine){
        res.status(400)
        throw new Error("Product line not found")
    }
    await productLine.remove()
    res.status(200).json({id: req.params.id})
})

module.exports = {
    getAllProductLines,
    getProductLineByShowID,
    getProductLineByDesigner,
    getProductLineByShowIDAndDesignerID,
    createProductLine,
    updateProductLine,
    deleteProductLine
}