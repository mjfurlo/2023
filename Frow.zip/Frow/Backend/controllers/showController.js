const asyncHandler = require('express-async-handler')
const mongoose = require("mongoose")
const Show = require("../models/showModel")


// @desc    Get all shows
// @route   GET /api/shows/all
// @access  Private
const getAllShows = asyncHandler(async (req, res) => {
    const shows = await Show.find();
    res.status(200).json(shows)
})

// @desc    Get shows by ID
// @route   GET /api/shows/:id
// @access  Private

const getShowById = asyncHandler(async(req, res) => {

    let show = await Show.findOne({
        _id: req.query.showID,
    });
    res.status(200).json(show)
})


// @desc    Create new show
// @route   POST /api/shows/createShow
// @access  Private

const createShow = asyncHandler(async(req, res) => {

    if(!req.body){
        res.status(400)
        throw new Error('Please add required fields')
    }
    const show = await Show.create({
        name: req.body.name,
        date: req.body.date,
        description: req.body.description,
        videoLink: req.body.videoLink,
        time: req.body.time,
        designerIDS: req.body.designerIDS
    })
    console.log(show)
    res.status(200).json(show)
})

// @desc    Update existing show
// @route   PUT /api/show/:id
// @access  Private

const updateShow = asyncHandler(async(req,res) => {
    const show = await Show.findById(req.params.id)

    if(!show){
        res.status(400)
        throw new Error ('Show not found')
    }
    const updatedShow = await Show.findByIdAndUpdate(req.params.id, req.body, {new: true})
    res.status(200).json(updatedShow)
})

// @desc    Delete existing show
// @route   DEL /api/show/:id
// @access  Private
const deleteShow = asyncHandler(async(req, res) => {
    const show = await Show.findById(req.params.id)

    if(!show){
        res.status(400)
        throw new Error("Show not found")
    }

    await show.remove()
    res.status(200).json({ id: req.params.id })
})





module.exports = {
    deleteShow,
    updateShow,
    createShow,
    getShowById,
    getAllShows
}