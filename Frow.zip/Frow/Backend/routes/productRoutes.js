const express = require('express')

const {
    createProduct,
    getAllProducts,
    getProductByDesigner,
    getProductByID,
    getProductByShow,
    updateProduct,
    deleteProduct,
    getProductByProductLine

} = require('../controllers/productController.js')
const { protect } = require("../middleware/authMiddleware.js")

const router = express.Router();

router.route("/createProduct").post(protect, createProduct)
router.route("/all").get(protect, getAllProducts)


router.route("/designer").get(protect, getProductByDesigner)
router.route("/show").get(protect, getProductByShow)
router.route("/").get(protect, getProductByID)
router.route("/productLine").get(protect, getProductByProductLine)

router
    .route("/:id")
    
    .put(protect, updateProduct)
    .delete(protect, deleteProduct)

module.exports = router