const express = require('express')

const {
    getAllProductLines,
    getProductLineByShowID,
    getProductLineByDesigner,
    getProductLineByShowIDAndDesignerID,
    createProductLine,
    updateProductLine,
    deleteProductLine
} = require('../controllers/lineController.js')
const { protect } = require('../middleware/authMiddleware.js')

const router = express.Router()

// Routes
router.route("/all").get(getAllProductLines)
router.route("/show").get(getProductLineByShowID)
router.route("/designer").get(getProductLineByDesigner)
router.route("/show&designer").get(getProductLineByShowIDAndDesignerID)
router.route("/createProductLine").post(createProductLine)

router
    .route("/:id")
    .put(updateProductLine)
    .delete(deleteProductLine)

// Export Module
module.exports = router