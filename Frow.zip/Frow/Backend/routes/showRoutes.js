const express = require('express')

const{
    getAllShows,
    getShowById,
    createShow,
    updateShow,
    deleteShow,
    getProductByProductLine
} = require("../controllers/showController.js");
const { protect } = require("../middleware/authMiddleware.js") ;

const router = express.Router();

router.route("/createShow").post(protect, createShow);
router.route("/all").get(protect, getAllShows)
router.route("/").get(protect, getShowById)

router
    .route("/:id")
    .put(protect, updateShow)
    .delete(protect, deleteShow)
    
    

module.exports = router